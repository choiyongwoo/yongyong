package com.example.myapplication;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.view.View;



import android.widget.EditText;

import android.widget.ImageButton;
import android.widget.Toast;




public class MainActivity extends AppCompatActivity {
    //activity_main.xml의 textview와 연결할 변수 선언
    int num[] = {R.id.etext2,  R.id.etext4, R.id.etext5,R.id.etext7,R.id.etext1};
    EditText [] etv = new EditText[5];

    //인바디 입력 변수 선언
    float height,weight, bmi, muscle, bfp, act,calorie, fm;
    String result;
    int tan, dan, ji;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for(int i=0;i<5;i++){
            etv[i]=findViewById(num[i]);
        }


        //활동지수 설명 액티비티
        ImageButton b2 = (ImageButton) findViewById(R.id.imageButton);
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,
                        question.class);

                startActivity(intent);
            }
        });




    }

    public void inbody(View view){


        //성별 선택하는 대화상자 이후, 성별이 여자일 때 인바디 입력에 따른 결과 다음 액티비티에 전달하는 메서드
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("성별을 선택하세요");
        alertDialogBuilder.setPositiveButton("여자",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        for(int i=0;i<5;i++){
                            if(etv[i].getText().toString().equals("")){
                                Toast.makeText(getApplicationContext(),"모든 값을 입력하십시오.",Toast.LENGTH_SHORT).show();
                                return;
                            }
                        }
                        weight= Float.parseFloat(etv[0].getText().toString());
                        muscle= Float.parseFloat(etv[1].getText().toString());
                        fm= Float.parseFloat(etv[2].getText().toString());
                        act= Float.parseFloat(etv[3].getText().toString());
                        height= Float.parseFloat(etv[4].getText().toString());
                        calorie=(height/100)*(height/100)*21*act;
                        bmi=weight/((height/100)*(height/100));
                        bfp=(fm/weight)*100;
                        if(bmi<18.5){
                            tan=55;
                            dan=25;
                            ji=20;
                            if(muscle<weight*0.4){
                                result="저체중 허약형";

                            }
                            else{
                                result="저체중 강인형";
                            }
                        }
                        else if(bmi>23){
                            if(muscle>weight*0.45){
                                if(bfp>20){
                                    tan=45;
                                    dan=30;
                                    ji=25;
                                    result="과체중 비만형";
                                }
                                else{
                                    tan=55;
                                    dan=25;
                                    ji=20;
                                    result="과체중 강인형";
                                }
                            }
                            else{
                                tan=45;
                                dan=25;
                                ji=30;
                                result="과체중 허약형";
                            }
                        }
                        else{
                            if(muscle>weight*0.45){
                                tan=55;
                                dan=25;
                                ji=20;
                                result="표준체중 강인형";
                            }
                            else{
                                if(bfp>28){
                                    tan=45;
                                    dan=25;
                                    ji=30;
                                    result="표준체중 비만형";
                                }
                                else{
                                    tan=55;
                                    dan=25;
                                    ji=20;
                                    result="표준체중 허약형";
                                }
                            }
                        }
                        //Activity2로 화면이동 하고 값 전달
                        Intent intent = new Intent(MainActivity.this,
                                Activity2.class);
                        intent.putExtra("result", result);
                        intent.putExtra("calorie",calorie);
                        intent.putExtra("tan", tan);
                        intent.putExtra("dan", dan);
                        intent.putExtra("ji", ji);
                        intent.putExtra("bmi", bmi);
                        intent.putExtra("bfp", bfp);
                        startActivity(intent);
                    }
                });

        ////성별 선택하는 대화상자 이후, 성별이 남자일 때 인바디 입력에 따른 결과 다음 액티비티에 전달하는 메서드
        alertDialogBuilder.setNegativeButton("남자",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                for(int i=0;i<5;i++){
                    if(etv[i].getText().toString().equals("")){
                        Toast.makeText(getApplicationContext(),"모든 값을 입력하십시오.",Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                weight= Float.parseFloat(etv[0].getText().toString());
                muscle= Float.parseFloat(etv[1].getText().toString());
                fm= Float.parseFloat(etv[2].getText().toString());
                act= Float.parseFloat(etv[3].getText().toString());
                height= Float.parseFloat(etv[4].getText().toString());
                calorie=(height/100)*(height/100)*22*act;
                bmi=weight/((height/100)*(height/100));
                bfp=(fm/weight)*100;
                if(bmi<18.5){
                    if(muscle<weight*0.4){
                        result="저체중 허약형";
                        tan=45;
                        dan=30;
                        ji=25;
                    }
                    else{
                        result="저체중 강인형";
                        tan=45;
                        dan=30;
                        ji=25;
                    }
                }
                else if(bmi>23){
                    if(muscle>weight*0.45){
                        if(bfp>20){
                            tan=45;
                            dan=30;
                            ji=25;
                            result="과체중 비만형";
                        }
                        else{
                            tan=55;
                            dan=25;
                            ji=20;
                            result="과체중 강인형";
                        }
                    }
                    else{
                        tan=45;
                        dan=25;
                        ji=30;
                        result="과체중 허약형";
                    }
                }
                else{
                    if(muscle>weight*0.45){
                        tan=55;
                        dan=25;
                        ji=20;
                        result="표준체중 강인형";
                    }
                    else{
                        if(bfp>20){
                            tan=45;
                            dan=25;
                            ji=30;
                            result="표준체중 비만형";
                        }
                        else{
                            tan=55;
                            dan=25;
                            ji=20;
                            result="표준체중 허약형";
                        }
                    }
                }

                //Activity2로 화면이동 하고 값 전달
                Intent intent = new Intent(MainActivity.this,
                        Activity2.class);
                intent.putExtra("result", result);
                intent.putExtra("calorie",calorie);
                intent.putExtra("tan", tan);
                intent.putExtra("dan", dan);
                intent.putExtra("ji", ji);
                intent.putExtra("bmi", bmi);
                intent.putExtra("bfp", bfp);
                startActivity(intent);
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }




}
