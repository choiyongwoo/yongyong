package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {
    //activity2.xml의 textview와 연결할 변수 선언
    TextView[] tv= new TextView[6];
    int num[] = {R.id.show_tv1,  R.id.show_tv2, R.id.show_tv3,R.id.show_tv4,R.id.show_tv5,R.id.show_tv6};
    String sentence;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        //activity2.xml의 textview와 변수 연결
        for(int i=0;i<6;i++){
            tv[i]=findViewById(num[i]);
        }

        //인텐트 선언하고 MainActivity로부터 인텐트로 값 전달받음
        Intent secondintent=getIntent();
        String category=secondintent.getStringExtra("result");
        Float calorie=secondintent.getFloatExtra("calorie",0);
        int tan=secondintent.getIntExtra("tan",0);
        int dan=secondintent.getIntExtra("dan",0);
        int ji=secondintent.getIntExtra("ji",0);
        Float bmi=secondintent.getFloatExtra("bmi",0);
        Float bfp=secondintent.getFloatExtra("bfp",0);

        //분류된 유형별 운동 방향을 추천하는 sentence
        switch(category){
            case "표준체중 강인형":
                sentence="근육량 자체가 많은 유형으로, 순수 근력운동만 하기 보다는 근력운동과 유산소운동을 병행하면 근육량은 유지시키면서 체지방을 감소시켜 운동효율을 더욱  높일 수 있습니다.";
                break;
            case "표준체중 비만형":
                sentence="근육량이 적어 근력운동에 많은 비중을 두는 것이 좋으며, 유산소운동은 약간 빠르게 걷는 정도의 속도로 20분 가량 병행하는 것이 적당합니다.";
                break;
            case "표준체중 허약형":
                sentence="운동 경험이 거의 전무한 경우 나타나는 유형으로, 이런 경우 근력운동에 비중을 두고 2~3개월 동안 적절한 운동과 식단만 병행하면 근육량을 최소 2kg 가량 증량할 수 있습니다.";
                break;
            case "저체중 허약형":
                sentence="체중과 근육량을 함께 늘려줘야 하며, 유산소운동은 생략하고 근력운동에만 비중을 두는 것이 효율적입니다.";
                break;
            case "저체중 강인형":
                sentence="체중은 표준 이하지만, 골격근이 잘 발달돼 있어 단단한 체형입니다. 무산소와 근력운동 비율을 동일하게 합니다";
                break;
            case "과체중 허약형":
                sentence="근육량은 적당하며, 체중 감량에 비중을 둬야 하는 유형으로 식단과 함께 유산소운동과 근력운동을 7:3의 비율로 병행해야 합니다.";
                break;
            case "과체중 강인형":
                sentence="운동 경력이 아주 오래된 경우 나타나는 유형으로, 근육량이 매우 많아 체중이 표준 이상으로 나타나게 됩니다.";
                break;
            case "과체중 비만형":
                sentence="다이어트와 근력운동의 밸런스를 5:5로 설정해야 하며, 근육량은 표준 이상이면 양호한 것으로 보고 근력운동을 통해 근육량을 최대한 유지시켜야 합니다.";
                break;

        }

        //인바디 결과를 추출하고, 필요한 일일 칼로리와 탄단지 비율, 필요한 영양소의 양(g)을 나타냄
        tv[0].setText(category);
        tv[1].setText(String.format("%.2f",bmi));
        tv[2].setText(String.format("%.2f",bfp));
        tv[3].setText(String.valueOf(calorie)+"kcal");
        tv[4].setText("탄"+String.valueOf(tan)+"%"+" "+"단"+String.valueOf(dan)+"%"+" "+"지"+String.valueOf(ji)+"%");
        tv[5].setText("탄수화물"+Math.round(Float.parseFloat(String.valueOf (calorie*tan/100/4)))+"g"+" "+"단백질"+Math.round(Float.parseFloat(String.valueOf(calorie*dan/100/4)))+"g"+" "+"지방"+Math.round(Float.parseFloat(String.valueOf(calorie*ji/100/4)))+"g");


        //Activity3으로 화면이동하고 값 값 전달
        Button button = (Button) findViewById(R.id.menu_btn1);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Activity2.this,
                        Activity3.class);
                intent.putExtra("sentence", sentence);
                startActivity(intent);
            }
        });

        //nutrient로 화면 이동
        Button btn = (Button) findViewById(R.id.nut_btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Activity2.this,
                        nutrient.class);
                startActivity(intent);
            }
        });
    }
}