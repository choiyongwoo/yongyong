package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {
    TextView tv1,tv2;
    String exer_ex[], link[];
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercise);

        //Activity2로부터 sentence값을 넘겨 받아 tv1에 sentence 표시
        Intent thirdintent=getIntent();
        String sentence=thirdintent.getStringExtra("sentence");
        tv1=findViewById(R.id.ex_text2);
        tv1.setText(sentence);

        //유산소, 무산소 운동에 대한 간략한 설명
        exer_ex=new String[]{"걷기:걷기 운동을 할 때 팔을 앞 뒤로 흔들고 보폭을 크게 하면 에너지 소비를 늘릴 수 있습니다. 경치를 즐기면서 걷는 것은 정신적인 스트레스 해소에도 큰 도움이 됩니다.",
        "조깅:  느린 속도로 달리는 유산소 운동이다. 주 목적은 빨리 달리는 것에 비해 몸에 압박을 덜 주면서 피트니스를 향상시키는 것이다. ",
        "계단 오르기: 계단 오르기를 30분간할 경우 가볍게 뛰는 것과 같은 칼로리를 소비할 수 있습니다. 단 충분히 스트레칭을 하고 관절 건강을 위해 내려올 때는 엘리베이터를 이용해야 합니다.",
                "줄넘기:1일 10분만 해도 효율적으로 지방을 연소할 수 있어서 관절이 튼튼한 젊은 세대의 다이어트 방법으로 좋습니다. ",
                "자전거 타기: 밖에 나가지 않아도 집에서 스마트폰이나 TV를 보면서 지루하지 않게 유산소 운동을 할 수 있습니다. 무릎에도 부담이 가해지지 않아서 관절 통증이 걱정되는 분들에게도 좋은 운동 종류입니다.",
                "맨몸 푸쉬업:  몸 전체가 하나의 단단한 통나무가 된다는 의식을 하고 팔의 전완부는 지면과 수직이 된 상태에서 축의 역할만 하도록 하며 그 상태에서 상완부만 바닥과 평행해지도록 팔꿈치를 접었다 폈다 하는 느낌으로 수행한다. ",
                "맨몸 풀업: 철봉을 어깨 넓이만큼 잡고 가슴을 들어주면서 들어놓은 가슴이 죽지 않도록 광배근으로 몸을 당겨준다.",
                "맨몸 스쿼트: 어깨 넓이로 발을 벌리고 서서 발가락이 전면을 향하도록 선 후, 허리는 곧게 펴고, 상체도 최대한 꼿꼿하게 펴는 것이 좋습니다. 그리고 무릎의 위치를 신경 쓰기보다는 의자에 앉는다는 느낌으로 자연스럽게 엉덩이를 낮추면 된다.",
                "맨몸 런지:  먼저 엉덩이 넓이로 다리를 벌리고 선 후, 상체를 펴고 코어에 힘을 주고, 어깨에 힘을 풀고, 턱을 치켜 드세요. 그리고 오른쪽 다리를 뻗어 한 걸음 나아가면서 두 무릎이 90도 각도를 이룰 때까지 엉덩이를 낮추어 줍니다. 앞쪽에 위치한 무릎이 발목 바로 위에 있도록 한다."
        };
        //유산소, 무산소 운동 관련 링크
        link=new String[]{"https://namu.wiki/w/%EA%B1%B7%EA%B8%B0",
                "https://ko.wikipedia.org/wiki/%EC%A1%B0%EA%B9%85",
                "https://namu.wiki/w/%EA%B3%84%EB%8B%A8%20%EC%98%A4%EB%A5%B4%EA%B8%B0",
                "https://namu.wiki/w/%EC%A4%84%EB%84%98%EA%B8%B0",
                "https://ko.wikipedia.org/wiki/%EC%9E%90%EC%A0%84%EA%B1%B0_%ED%83%80%EA%B8%B0",
                "https://www.youtube.com/watch?v=aoH7qNedO8k",
        "https://www.youtube.com/watch?v=VhfJB-VQOfg",
        "https://www.youtube.com/watch?v=9Sl5tI4_J-0",
        "https://www.youtube.com/watch?v=7erin-2cpRo"};

        //유산소,무산소 운동을 포함하는 갤러리뷰
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Gallery gallery1 = (Gallery) findViewById(R.id.gallery1);

        MyGalleryAdapter galAdapter = new MyGalleryAdapter(this);
        gallery1.setAdapter(galAdapter);
    }



    public class MyGalleryAdapter extends BaseAdapter {

        Context context;
        Integer[] exerID = {  R.drawable.walk, R.drawable.jogging1,
                R.drawable.stair1, R.drawable.jumprope1, R.drawable.bicycle1,
                R.drawable.pushup1, R.drawable.pullup1, R.drawable.squat1, R.drawable.lunge1 };

        public MyGalleryAdapter(Context c) {
            context = c;
        }

        public int getCount() {
            return exerID.length;
        }

        public Object getItem(int arg0) {
            return null;
        }

        public long getItemId(int position) {
            return 0;
        }


        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageview = new ImageView(context);
            imageview.setLayoutParams(new Gallery.LayoutParams(100, 200));
            imageview.setScaleType(ImageView.ScaleType.FIT_START);
            imageview.setPadding(5, 5, 5, 5);
            imageview.setImageResource(exerID[position]);
            final int pos = position;

            //갤러리뷰에서 이미지를 터치하면 생성
            imageview.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    ImageView igmv1 = (ImageView) findViewById(R.id.ex_img1);
                    igmv1.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    igmv1.setImageResource(exerID[pos]);
                    tv2=(TextView) findViewById(R.id.ex_text4);
                    tv2.setText(exer_ex[pos]);
                    //생긴 이미지를 클릭하면 링크에 들어갈 수 있는 팝업메뉴 생성
                    igmv1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            final PopupMenu popupMenu = new PopupMenu(getApplicationContext(),view);
                            popupMenu.getMenuInflater().inflate(R.menu.menu_main, popupMenu.getMenu());
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                public boolean onMenuItemClick(MenuItem item) {
                                    if(item.getItemId()==R.id.item1){
                                        Intent intent;
                                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link[pos]));
                                        startActivity(intent);
                                    }
                                    else{
                                        return true;
                                    }
                                    return true;

                                }
                            });
                            popupMenu.show();
                        }
                    });
                    return false;
                }
            });



            return imageview;
        }
    }

}



