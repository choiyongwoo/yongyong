package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

import android.view.View;


import android.widget.Button;


public class question extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        //MainActivity로 돌아가는 intent
        Button b1 = (Button) findViewById(R.id.index_btn1);
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(question.this,
                        MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
