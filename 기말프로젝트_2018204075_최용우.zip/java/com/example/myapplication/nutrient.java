package com.example.myapplication;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;






public class nutrient extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //nutrient 화면을 보여주기 위한 activity
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nutrient);





    }
}